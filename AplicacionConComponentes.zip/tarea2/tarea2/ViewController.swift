//
//  ViewController.swift
//  tarea2
//
//  Created by Alumno on 14/10/22.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var numeroInferior: UITextField!
    @IBOutlet weak var numeroSuperior: UITextField!
    @IBOutlet weak var contrasenaTextField: UITextField!
    @IBOutlet weak var usuarioTextField: UITextField!
    
    func showAlert(mensaje: String){
        let alert = UIAlertController(title: "Alerta!!", message: mensaje, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Cerrar", style: UIAlertAction.Style.cancel))
        self.present(alert, animated: true, completion: nil)
    }
    
    /*
    @IBAction func alertaButton(_ sender: UIButton) {
        let mensaje: String = usuarioTextField.text!
            showAlert(mensaje: mensaje)
    }
    */
    
    @IBAction func sumaButton(_ sender: UIButton) {
        let numSup = Double(numeroSuperior.text ?? "0")
        let numInf = Double(numeroInferior.text ?? "0")
        var mensaje: String = "poner ambas"
        
        if(numSup != nil && numInf != nil){
            let res = (numSup!) + (numInf!)
            mensaje = String(res)
        }
        showAlert(mensaje: mensaje)
    }
    @IBAction func restaButton(_ sender: UIButton) {
        let numSup = Double(numeroSuperior.text ?? "0")
        let numInf = Double(numeroInferior.text ?? "0")
        var mensaje: String = "poner ambas"
        
        if(numSup != nil && numInf != nil){
            let res = (numSup!) - (numInf!)
            mensaje = String(res)
        }
        showAlert(mensaje: mensaje)
    }
    
    @IBAction func multButton(_ sender: UIButton) {
        let numSup = Double(numeroSuperior.text ?? "0")
        let numInf = Double(numeroInferior.text ?? "0")
        var mensaje: String = "poner ambas"
        
        if(numSup != nil && numInf != nil){
            let res = (numSup!) * (numInf!)
            mensaje = String(res)
        }
        showAlert(mensaje: mensaje)
    }
    
    @IBAction func divButton(_ sender: UIButton) {
        let numSup = Double(numeroSuperior.text ?? "0")
        let numInf = Double(numeroInferior.text ?? "0")
        var mensaje: String = "poner ambas"
        
        if(numSup != nil && numInf != nil){
            let res = (numSup!) / (numInf!)
            mensaje = String(res)
        }
        showAlert(mensaje: mensaje)
    }
    
    
    
    @IBAction func botonalerta(_ sender: UIButton) {
        
    }
    

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        usuarioTextField.text = "Segunda Aplicación"
        usuarioTextField.textColor = UIColor(red: 36/255, green: 80/255, blue: 155/255, alpha: 1.0)
    }


}

